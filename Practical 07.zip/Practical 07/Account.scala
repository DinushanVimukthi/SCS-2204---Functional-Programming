class Bank(Acc:List[Account]){
    def Accounts:List[Account]=Acc
    def NegativeBalance():List[Account]=Accounts.filter(x=>x.Money<0)
    def TotalBalance():Double=Accounts.map(x=>x.Money).sum
    def ApplyInterest()=Accounts.map(x=>x.Interest())
}


class Account(amount:Int){
    var Money = amount
    def transfer(target:Account, n:Int) = {
        this.Money = this.Money - n
        target.Money = target.Money + n
    }
    override def toString(): String = "$" + Money
    def Interest():Double= this.Money match
        case x if x>0 => this.Money*0.05
        case x if x<0 => this.Money*0.1
        case _ => 0
    
}

@main
def run()={
    val a = new Account(100)
    val b = new Account(200)
    // println("Money in Account A "+a)
    // println("Money in Account B "+b)
    // a.transfer(b, 50)
    // println("After Transfer-")
    // println("Money in Account A "+a)
    // println("Money in Account B "+b)
    val c = new Account(300)
    val d = new Account(-200)
    val e = new Account(-300)
    val Bank= new Bank(List(a,b,c,d,e))
    println("Negative Balance Accounts "+Bank.NegativeBalance())
    println("Total Balance "+Bank.TotalBalance())
    println("After Interest")
    Bank.ApplyInterest()
    println("Negative Balance Accounts "+Bank.NegativeBalance())
    println("Total Balance "+Bank.TotalBalance())

}